﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2_两个有序数组的中位数
{
    class Solution
    {
        public double FindMedianSortedArrays(int[] nums1, int[] nums2)
        {

        }
    }
    class FindMedianSortedArrays
    {
        static void Main(string[] args)
        {
        }
    }
}
